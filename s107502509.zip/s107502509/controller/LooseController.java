package ce1002.f1.s107502509.controller;

import java.io.IOException;

import ce1002.f1.s107502509.finalproject;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;

public class LooseController {
	public void PlayAgain(ActionEvent e) throws IOException {
	    FXMLLoader loadder = new FXMLLoader(getClass().getResource("../views/sceneone.fxml"));
	    Parent first = loadder.load();
	    Scene firstScene = new Scene(first);
	    SceneoneController onecontrol = loadder.getController();
	    firstScene.setOnKeyPressed(onecontrol.onKeyPressed);
	    finalproject.mainStage.setScene(firstScene);
	    MainController.minute = 5;
	    MainController.second = 1;
	}
	public void OnExitPressed(ActionEvent e) {
		finalproject.mainStage.close();
	}

}
