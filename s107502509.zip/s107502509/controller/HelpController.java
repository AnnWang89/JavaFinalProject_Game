package ce1002.f1.s107502509.controller;
import ce1002.f1.s107502509.finalproject;
import javafx.event.ActionEvent;

public class HelpController {
	public void OnBackPressed(ActionEvent e) {
		
		    finalproject.mainStage.setScene(finalproject.mainScene);
	}
}
