/*
 * Final Project
 * Course: ce1002
 * Name: ���g�w
 * Student ID: 107502509
 */
package ce1002.f1.s107502509;

import java.io.IOException;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;


public class finalproject extends Application{

	public static Stage mainStage;
	public static Scene mainScene;
	
	@Override
	public void start(Stage primaryStage) throws IOException {
		finalproject.mainStage = primaryStage;
	    FXMLLoader loadder = new FXMLLoader(getClass().getResource("views/main.fxml"));//
	    Parent main = loadder.load();    
	   mainScene = new Scene(main);
	    mainStage.setTitle("File");//title name
	    mainStage.setScene(mainScene);//set scene to mainScene
	   
	    mainStage.show();//show the Stage
	}
	
	public static void main(String[] args){
	    launch(args);
	}

}

